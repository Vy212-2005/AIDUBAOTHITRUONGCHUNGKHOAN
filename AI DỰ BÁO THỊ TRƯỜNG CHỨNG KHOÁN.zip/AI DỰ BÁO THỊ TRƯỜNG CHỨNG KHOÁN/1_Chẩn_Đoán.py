import streamlit as st
import plotly.graph_objects as go
from plotly.subplots import make_subplots

def create_stock_chart(df, ticker, c_p, o_p, h_p, l_p, v_p, avg_v):
    """Tạo biểu đồ hình nến (Candlestick) kết hợp khối lượng và các chỉ số kỹ thuật."""
    fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.03, row_heights=[0.75, 0.25])
    
    # Biểu đồ nến chính
    fig.add_trace(go.Candlestick(
        x=df.index[-100:], 
        open=df['Open'][-100:], high=df['High'][-100:], low=df['Low'][-100:], close=df['Close'][-100:],
        name='Giá nến',
        increasing_line_color='#00ff88', decreasing_line_color='#ff4b4b'
    ), row=1, col=1)
    
    # Các đường chỉ số kỹ thuật
    fig.add_trace(go.Scatter(x=df.index[-100:], y=df['Open'][-100:], name='Giá Mở cửa', line=dict(color='#94a3b8', width=1, dash='dash')), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index[-100:], y=df['SMA20'][-100:], name='SMA 20', line=dict(color='#ff9f43', width=1.5)), row=1, col=1)
    fig.add_trace(go.Scatter(x=df.index[-100:], y=df['EMA20'][-100:], name='EMA 20', line=dict(color='#4facfe', width=1.5, dash='dot')), row=1, col=1)
    
    # Biểu đồ khối lượng (Volume)
    vol_colors = ['#00ff88' if c >= o else '#ff4b4b' for o, c in zip(df['Open'][-100:], df['Close'][-100:])]
    fig.add_trace(go.Bar(x=df.index[-100:], y=df['Volume'][-100:], marker_color=vol_colors, name='Khối lượng', opacity=0.8), row=2, col=1)
    
    fig.update_layout(
        template='plotly_dark',
        xaxis_rangeslider_visible=False,
        height=650,
        margin=dict(t=30, b=0, l=10, r=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)',
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        annotations=[
            dict(
                x=0.01, y=0.99, xref="paper", yref="paper",
                text=f"<span style='color: {'#00ff88' if c_p >= o_p else '#ff4b4b'}; font-size: 14px;'>"
                     f"<b>MỞ:</b> {o_p:,.2f} | <b>CAO:</b> {h_p:,.2f} | <b>THẤP:</b> {l_p:,.2f} | <b>ĐÓNG:</b> {c_p:,.2f} <br>"
                     f"<b>VOL:</b> {v_p:,.0f} | <b>AVG VOL (30N):</b> {avg_v:,.0f}"
                     f"</span>",
                showarrow=False,
                font=dict(family="Inter, sans-serif"),
                bgcolor="rgba(0,0,0,0.7)",
                bordercolor="#4facfe",
                borderwidth=1,
                borderpad=6,
                align="left"
            )
        ]
    )
    return fig
