import streamlit as st
from ta.trend import SMAIndicator, EMAIndicator
from ta.momentum import RSIIndicator

def ve_the_hieu_suat(col, nhan, gia_tri):
    """Vẽ thẻ biến động phần trăm (Xanh/Đỏ)."""
    mau = "#10b981" if gia_tri >= 0 else "#ef4444"
    icon = "▲" if gia_tri >= 0 else "▼"
    col.markdown(f"""
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); border-radius: 12px; padding: 15px; text-align: center;">
            <div style="color: #94a3b8; font-size: 0.7rem; font-weight: 600;">{nhan}</div>
            <div style="color: {mau}; font-size: 1.4rem; font-weight: 800;">{icon} {gia_tri:+.2f}%</div>
        </div>
    """, unsafe_allow_html=True)

def ve_the_chi_so(col, nhan, gia_tri, delta=None, delta_text=""):
    """Vẽ thẻ chỉ số tài chính cơ bản."""
    delta_class = "metric-delta-up" if (delta and delta >= 0) else "metric-delta-down"
    delta_val = f"{delta:+.2f}%" if delta is not None else delta_text
    col.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">{nhan}</div>
            <div class="metric-value">{gia_tri}</div>
            <div class="{delta_class}">{delta_val}</div>
        </div>
    """, unsafe_allow_html=True)

def tinh_toan_chi_bao(df):
    """Tính toán các chỉ số kỹ thuật từ dataframe."""
    df = df.copy()
    df['SMA20'] = SMAIndicator(close=df['Close'], window=20).sma_indicator()
    df['SMA50'] = SMAIndicator(close=df['Close'], window=50).sma_indicator()
    df['SMA100'] = SMAIndicator(close=df['Close'], window=100).sma_indicator()
    df['SMA200'] = SMAIndicator(close=df['Close'], window=200).sma_indicator()
    df['EMA20'] = EMAIndicator(close=df['Close'], window=20).ema_indicator()
    df['RSI'] = RSIIndicator(close=df['Close'], window=14).rsi()
    return df
