import streamlit as st
import pandas as pd
import datetime
import os
import plotly.express as px
import yfinance as yf

LOG_FILE = "truy_cap_log.csv"
# Danh sách mã được quan tâm toàn cầu
GLOBAL_TICKERS = ["AAPL", "TSLA", "NVDA", "MSFT", "GOOGL", "BTC-USD", "ETH-USD", "VND=X", "XAU=F", "META"]

def ghi_log_truy_cap(ticker, hanh_dong):
    """Ghi lại lịch sử truy cập mã cổ phiếu và tính năng."""
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_data = pd.DataFrame([[now, ticker, hanh_dong]], columns=["Thời gian", "Mã", "Tính năng"])
    
    if not os.path.isfile(LOG_FILE):
        new_data.to_csv(LOG_FILE, index=False, encoding='utf-8-sig')
    else:
        new_data.to_csv(LOG_FILE, mode='a', header=False, index=False, encoding='utf-8-sig')

def doc_log_truy_cap():
    """Đọc dữ liệu từ file log."""
    if not os.path.isfile(LOG_FILE):
        return pd.DataFrame(columns=["Thời gian", "Mã", "Tính năng"])
    return pd.read_csv(LOG_FILE)

@st.cache_data(ttl=3600)
def lay_du_lieu_the_gioi():
    """Lấy dữ liệu biến động giá của các mã phổ biến trên thế giới."""
    data = []
    try:
        # Tải dữ liệu 2 ngày gần nhất để tính % biến động
        df = yf.download(GLOBAL_TICKERS, period="2d", group_by='ticker', progress=False)
        
        for t in GLOBAL_TICKERS:
            try:
                # Trích xuất dữ liệu cho từng mã từ MultiIndex DataFrame
                if len(GLOBAL_TICKERS) > 1:
                    ticker_df = df[t]
                else:
                    ticker_df = df
                
                # Bỏ qua nếu không có dữ liệu hoặc toàn giá trị NaN
                if ticker_df.empty or ticker_df['Close'].isnull().all():
                    continue

                # Lấy 2 giá đóng cửa gần nhất (loại bỏ NaN)
                prices = ticker_df['Close'].dropna()
                if len(prices) >= 2:
                    c = prices.iloc[-1]
                    p = prices.iloc[-2]
                    change = ((c - p) / p) * 100
                    data.append({"Mã": t, "Giá Hiện Tại": c, "Biến động (%)": change})
            except Exception:
                continue
    except Exception as e:
        st.error(f"Lỗi tải dữ liệu thế giới: {e}")
    
    res_df = pd.DataFrame(data)
    if not res_df.empty:
        return res_df.sort_values(by="Biến động (%)", ascending=False)
    return res_df

def hien_thi_thong_ke():
    """Giao diện hiển thị thống kê và lịch sử."""
    st.markdown("## 📊 Thống Kê & Xu Hướng Thị Trường")
    
    df_log = doc_log_truy_cap()
    
    # 1. Thống kê tổng quan (Vẫn giữ lại)
    if not df_log.empty:
        c1, c2, c3 = st.columns(3)
        c1.metric("Tổng lượt truy cập", len(df_log))
        c2.metric("Số mã bạn đã tra", df_log['Mã'].nunique())
        c3.metric("Tính năng dùng nhiều", df_log['Tính năng'].mode()[0] if not df_log['Tính năng'].empty else "N/A")
        st.divider()

    # 2. Tabs phân chia thế giới và cá nhân
    tab_global, tab_personal = st.tabs(["🌍 Xu Hướng Toàn Cầu", "👤 Lịch Sử Cá Nhân"])

    with tab_global:
        st.subheader("🔥 Các mã được quan tâm trên thế giới")
        with st.spinner("Đang tải dữ liệu thế giới..."):
            df_world = lay_du_lieu_the_gioi()
        
        if not df_world.empty:
            col_chart, col_table = st.columns([0.6, 0.4])
            with col_chart:
                # Biểu đồ biến động %
                fig = px.bar(df_world, x='Mã', y='Biến động (%)', color='Biến động (%)',
                             title="Biến động trong ngày (%)",
                             template='plotly_dark', 
                             color_continuous_scale='RdYlGn') # Đỏ sang Xanh
                st.plotly_chart(fig, use_container_width=True)
            
            with col_table:
                st.dataframe(df_world, height=400, hide_index=True, use_container_width=True)
        else:
            st.warning("Không thể tải dữ liệu xu hướng thế giới lúc này.")

    with tab_personal:
        if df_log.empty:
            st.info("Chưa có dữ liệu lịch sử cá nhân.")
        else:
            col_p_chart, col_p_table = st.columns([0.6, 0.4])
            with col_p_chart:
                st.subheader("📈 Mã bạn tra cứu nhiều nhất")
                top_p = df_log['Mã'].value_counts().head(10).reset_index()
                top_p.columns = ['Mã', 'Lượt xem']
                fig_p = px.pie(top_p, values='Lượt xem', names='Mã', hole=0.4,
                               template='plotly_dark', color_discrete_sequence=px.colors.qualitative.Plotly)
                st.plotly_chart(fig_p, use_container_width=True)
            
            with col_p_table:
                st.subheader("📋 Bảng xếp hạng")
                st.dataframe(top_p, hide_index=True, use_container_width=True)
            
            st.divider()
            st.subheader("🕒 Nhật ký tra cứu gần đây")
            st.dataframe(df_log.iloc[::-1], use_container_width=True, hide_index=True)

    # Nút xóa lịch sử (Vẫn giữ ở cuối)
    if not df_log.empty:
        if st.button("🗑️ Xóa lịch sử cá nhân"):
            if os.path.exists(LOG_FILE):
                os.remove(LOG_FILE)
                st.success("Đã xóa lịch sử thành công!")
                st.rerun()
