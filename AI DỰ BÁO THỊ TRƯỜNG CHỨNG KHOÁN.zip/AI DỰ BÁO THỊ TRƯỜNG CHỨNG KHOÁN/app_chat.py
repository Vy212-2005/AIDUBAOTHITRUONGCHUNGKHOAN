import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import importlib
from PIL import Image

# Nhập các module chuyên ngành Chứng khoán 1-5
PhanTichKT = importlib.import_module("1_Phân_Tích_Kỹ_Thuật")
DuLieuLS = importlib.import_module("2_Dữ_Liệu_Lịch_Sử")
ChiSoTT = importlib.import_module("3_Chỉ_Số_Thị_Trường")
TinTucSK = importlib.import_module("4_Tin_Tức_Sự_Kiện")
MoHinhDB = importlib.import_module("5_Mô_Hình_Dự_Báo")

from hang_so import CSS_CHUNG_KHOAN

# --- 1. SETUP ---
st.set_page_config(page_title="AI Dự Báo Chứng Khoán", layout="wide")
st.markdown(CSS_CHUNG_KHOAN, unsafe_allow_html=True)

if "ticker" not in st.session_state: st.session_state.ticker = "AAPL"
ai_model = None

# --- 2. SIDEBAR ---
with st.sidebar:
    st.title("� StockPrediction AI")
    key = st.text_input("Gemini API Key", type="password")
    if key: ai_model = MoHinhDB.cau_hinh_gemini(key)
    
    ticker_in = st.text_input("Nhập mã (VNM, AAPL...)", value=st.session_state.ticker).upper()
    if ticker_in != st.session_state.ticker:
        st.session_state.ticker = ticker_in
        st.rerun()
    ticker = st.session_state.ticker

# --- 3. MAIN APP ---
st.markdown(f"<h1 class='main-title'>Dự Báo Thị Trường: {ticker}</h1>", unsafe_allow_html=True)

try:
    df = yf.download(ticker, period='2y')
    if df.empty: st.error("Không có dữ liệu"); st.stop()
    
    df = ChiSoTT.tinh_toan_chi_bao(df)
    cp = df['Close'].iloc[-1]; op = df['Open'].iloc[-1]
    hp = df['High'].iloc[-1]; lp = df['Low'].iloc[-1]
    vol = df['Volume'].iloc[-1]; avg_v = df['Volume'].tail(30).mean()
    ma20 = df['SMA20'].iloc[-1]; rsi = df['RSI'].iloc[-1]
    bien_dong = ((cp - df['Close'].iloc[-2]) / df['Close'].iloc[-2]) * 100

    tabs = st.tabs(["� Phân Tích Kỹ Thuật", "� Lịch Sử & Hiệu Suất", "� Chỉ Số Thị Trường", "📰 Tin Tức & Sự Kiện", "🤖 Dự Báo AI"])

    with tabs[0]:
        st.plotly_chart(PhanTichKT.tao_bieu_do_ky_thuat(df, ticker, cp, op, hp, lp, vol, avg_v), use_container_width=True)

    with tabs[1]:
        c1, c2, c3, c4 = st.columns(4)
        ChiSoTT.ve_the_hieu_suat(c1, "1 Ngày", bien_dong)
        ChiSoTT.ve_the_hieu_suat(c2, "1 Tuần", DuLieuLS.tinh_bien_dong_ky(df, 5))
        ChiSoTT.ve_the_hieu_suat(c3, "1 Tháng", DuLieuLS.tinh_bien_dong_ky(df, 21))
        ChiSoTT.ve_the_hieu_suat(c4, "1 Năm", DuLieuLS.tinh_bien_dong_ky(df, 252))

    with tabs[2]:
        m1, m2, m3, m4 = st.columns(4)
        sym = "$" # Simplified for now
        ChiSoTT.ve_the_chi_so(m1, "Giá Hiện Tại", f"{sym}{cp:,.2f}", bien_dong)
        ChiSoTT.ve_the_chi_so(m2, "Xu Hướng (MA20)", "TĂNG" if cp > ma20 else "GIẢM", delta=0 if cp > ma20 else -1)
        ChiSoTT.ve_the_chi_so(m3, "RSI (14)", f"{rsi:.1f}", delta_text="Ổn Định" if 30<=rsi<=70 else "Biến Động")
        
        # LSTM Simulation for placeholder
        ChiSoTT.ve_the_chi_so(m4, "Dự Báo (Mô Hình)", "N/A", delta_text="Cần Load Model")

    with tabs[3]:
        TinTucSK.hien_thi_tin_tuc(ticker, f"Tin tức {ticker}")

    with tabs[4]:
        st.markdown("### 💬 Tư Vấn Chiến Lược AI")
        if "chat" not in st.session_state: st.session_state.chat = []
        for m in st.session_state.chat:
            with st.chat_message(m["role"]): st.markdown(m["content"])
        
        anh_tai = st.file_uploader("Tải biểu đồ phân tích", type=["jpg","png"])
        anh = Image.open(anh_tai) if anh_tai else None
        
        if p := st.chat_input("Hỏi AI về chiến lược mua/bán..."):
            st.session_state.chat.append({"role": "user", "content": p})
            with st.chat_message("user"): st.markdown(p)
            with st.chat_message("assistant"):
                if ai_model:
                    ctx = f"Mã: {ticker}, Giá: {cp:.2f}, RSI: {rsi:.1f}. Câu hỏi: {p}"
                    res, err = MoHinhDB.goi_phan_tich_ai(ai_model, ctx, anh)
                    if res: st.markdown(res); st.session_state.chat.append({"role": "assistant", "content": res})
                    else: st.error(err)
                else: st.warning("Hãy nhập API Key ở Sidebar")

except Exception as e:
    st.error(f"Hệ thống lỗi: {e}")
