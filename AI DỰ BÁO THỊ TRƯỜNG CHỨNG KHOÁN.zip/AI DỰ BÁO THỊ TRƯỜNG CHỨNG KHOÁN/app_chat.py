import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import time
from PIL import Image

# Nhập các module đã đánh số (Thứ tự 1-5)
import importlib
Chuẩn_Đoán = importlib.import_module("1_Chẩn_Đoán")
Lịch_Sử = importlib.import_module("2_Lịch_Sử")
Thống_Kê = importlib.import_module("3_Thống_Kê")
Phân_Tích_GT = importlib.import_module("4_Phân_Tích_Giấy_Tờ")
Trợ_Lý_AI = importlib.import_module("5_Trợ_Lý_AI")

from hang_so import DUONG_DAN_PYTHON, CSS_GIAO_DIEN
from tien_ich import run_training # Các hàm nền tảng vẫn dùng tien_ich hoặc gộp chung

# --- 1. THIẾT LẬP BAN ĐẦU ---
st.set_page_config(page_title="DeepStock AI Pro", layout="wide", initial_sidebar_state="expanded")
st.markdown(CSS_GIAO_DIEN, unsafe_allow_html=True)

if "ticker" not in st.session_state:
    st.session_state.ticker = "AAPL"

gemini_model = None

# --- 2. THANH BÊN (SIDEBAR) ---
with st.sidebar:
    st.markdown("<h2 style='color: #4facfe;'>💎 DeepStock Pro</h2>", unsafe_allow_html=True)
    st.markdown("### 🔑 Cấu hình AI")
    user_api_key = st.text_input("Dán Gemini API Key", value="", type="password")
    if user_api_key:
        gemini_model = Trợ_Lý_AI.configure_gemini(user_api_key)

    st.markdown("### 🔍 Tìm kiếm")
    ticker_input = st.text_input("Mã chứng khoán", value=st.session_state.ticker).upper()
    if ticker_input != st.session_state.ticker:
        st.session_state.ticker = ticker_input
        st.rerun()

    ticker = st.session_state.ticker
    st.markdown("### 🗂️ Danh mục")
    pop_tabs = st.tabs(["VN", "Glo", "Cry", "Fx"])
    with pop_tabs[1]:
        if st.button("AAPL"): st.session_state.ticker = "AAPL"; st.rerun()
        if st.button("TSLA"): st.session_state.ticker = "TSLA"; st.rerun()

    st.markdown("---")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Huấn luyện"):
            with st.status(f"🛠️ Training {ticker}..."):
                from tien_ich import run_training
                proc = run_training(ticker)
                if proc: proc.wait(); st.success("Xong!")
    with col2:
        if st.button("Làm mới"): st.rerun()

# --- 3. DASHBOARD ---
st.markdown(f"<h1 class='main-title'>DeepStock AI: {ticker}</h1>", unsafe_allow_html=True)

try:
    df = yf.download(ticker, period='2y')
    if isinstance(df.columns, pd.MultiIndex): df.columns = df.columns.get_level_values(0)
    if df.empty: st.error("Lỗi dữ liệu"); st.stop()

    df = Thống_Kê.get_technical_indicators(df)
    
    # Pre-calc
    c_p = df['Close'].iloc[-1]; o_p = df['Open'].iloc[-1]
    h_p = df['High'].iloc[-1]; l_p = df['Low'].iloc[-1]
    v_p = df['Volume'].iloc[-1]; avg_v = df['Volume'].tail(30).mean()
    prev_c = df['Close'].iloc[-2]
    change = ((c_p - prev_c) / prev_c) * 100
    ma20 = df['SMA20'].iloc[-1]; rsi = df['RSI'].iloc[-1]

    # --- TABS ---
    tab_1, tab_2, tab_3, tab_4, tab_5 = st.tabs(["🚀 Chẩn Đoán", "📈 Lịch Sử", "📊 Thống Kê", "📰 Giấy Tờ/Tin Tức", "📂 Dữ Liệu"])

    with tab_1:
        st.markdown("### 📊 Tổng quan & Biểu đồ")
        fig = Chuẩn_Đoán.create_stock_chart(df, ticker, c_p, o_p, h_p, l_p, v_p, avg_v)
        st.plotly_chart(fig, use_container_width=True)

    with tab_2:
        st.markdown("### 🕒 Biến động & Lịch sử")
        col_p1, col_p2, col_p3, col_p4 = st.columns(4)
        change_1w = Lịch_Sử.get_period_change(df, 5)
        change_1m = Lịch_Sử.get_period_change(df, 21)
        change_1y = Lịch_Sử.get_period_change(df, 252)
        Thống_Kê.draw_perf_card(col_p1, "1 Ngày", change)
        Thống_Kê.draw_perf_card(col_p2, "1 Tuần", change_1w)
        Thống_Kê.draw_perf_card(col_p3, "1 Tháng", change_1m)
        Thống_Kê.draw_perf_card(col_p4, "1 Năm", change_1y)

    with tab_3:
        st.markdown("### 📊 Chỉ số Thống kê")
        col_m1, col_m2, col_m3, col_m4 = st.columns(4)
        curr_sym = "$" # Simplified
        Thống_Kê.draw_metric_card(col_m1, "Giá hiện tại", f"{curr_sym}{c_p:,.2f}", change)
        trend_status = "TĂNG" if c_p > ma20 else "GIẢM"
        Thống_Kê.draw_metric_card(col_m2, "Xu hướng (MA20)", trend_status, delta=0 if trend_status == "TĂNG" else -1, delta_text=trend_status)
        rsi_desc = "Quá mua" if rsi > 70 else ("Quá bán" if rsi < 30 else "Ổn định")
        Thống_Kê.draw_metric_card(col_m3, "RSI (14)", f"{rsi:.1f}", delta=0 if 30 <= rsi <= 70 else -1, delta_text=rsi_desc)
        
        # AI Pred
        model, scaler = Lịch_Sử.load_assets(ticker)
        if model and scaler:
            feature_cols = ['Open', 'High', 'Low', 'Close', 'SMA20', 'SMA50', 'EMA20', 'RSI', 'Volume']
            last_60 = df[feature_cols].tail(60).values
            scaled = scaler.transform(last_60)
            pred = model.predict(np.reshape(scaled, (1, 60, len(feature_cols))), verbose=0)
            dummy = np.zeros((1, len(feature_cols))); target_idx = 3 # Close
            dummy[0, target_idx] = pred[0][0]
            pred_p = float(scaler.inverse_transform(dummy)[0][target_idx])
            pred_change = ((pred_p - c_p)/c_p)*100
            Thống_Kê.draw_metric_card(col_m4, "Dự báo T+1", f"{curr_sym}{pred_p:,.2f}", pred_change)
        else:
            Thống_Kê.draw_metric_card(col_m4, "Dự báo T+1", "N/A", delta_text="No Model")

    with tab_4:
        Phân_Tích_GT.display_news(ticker, "📊 Tin tức " + ticker)

    with tab_5:
        st.dataframe(df.tail(100).sort_index(ascending=False), use_container_width=True)

    # --- CHAT ---
    st.markdown("### 💬 Trợ lý AI")
    if "messages" not in st.session_state: st.session_state.messages = []
    for msg in st.session_state.messages:
        with st.chat_message(msg["role"]): st.markdown(msg["content"])
    
    uploaded_file = st.file_uploader("Phân tích ảnh", type=["png", "jpg"])
    chart_image = Image.open(uploaded_file) if uploaded_file else None
    
    if prompt := st.chat_input("Hỏi AI..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"): st.markdown(prompt)
        with st.chat_message("assistant"):
            if gemini_model:
                context = f"Mã: {ticker}, Giá: {c_p:.2f}. Câu hỏi: {prompt}"
                res, err = Trợ_Lý_AI.get_ai_response(gemini_model, context, chart_image)
                if res: st.markdown(res); st.session_state.messages.append({"role": "assistant", "content": res})
                else: st.error(err)
            else: st.warning("Cấu hình API Key trước")

except Exception as e:
    st.error(f"Lỗi: {e}")
