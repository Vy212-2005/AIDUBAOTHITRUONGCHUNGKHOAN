import yfinance as yf
import pandas as pd
from ta.trend import SMAIndicator

ticker = "AAPL"
df = yf.download(ticker, period='2y')

print(f"Original columns type: {type(df.columns)}")
print(f"Original Close shape: {df['Close'].shape}")

# Flatten MultiIndex
if isinstance(df.columns, pd.MultiIndex):
    df.columns = df.columns.get_level_values(0)

print(f"New columns: {df.columns}")
print(f"New Close shape: {df['Close'].shape}")

# Test SMA calculation (this was likely failing)
try:
    sma = SMAIndicator(close=df['Close'], window=20).sma_indicator()
    print("SMA calculation successful!")
except Exception as e:
    print(f"SMA calculation failed: {e}")
