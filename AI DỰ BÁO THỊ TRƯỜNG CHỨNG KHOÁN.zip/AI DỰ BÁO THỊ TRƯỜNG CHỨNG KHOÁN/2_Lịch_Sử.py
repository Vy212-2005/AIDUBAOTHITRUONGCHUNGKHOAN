import streamlit as st
import os
import joblib
from tensorflow.keras.models import load_model

def load_assets(ticker):
    """Tải model Keras và bộ chuẩn hóa Scaler cho mã chứng khoán tương ứng."""
    try:
        m_path = f'model_{ticker.lower()}.keras'
        s_path = f'scaler_{ticker.lower()}.pkl'
        if os.path.exists(m_path) and os.path.exists(s_path):
            m = load_model(m_path)
            s = joblib.load(s_path)
            return m, s
    except Exception as e:
        st.warning(f"Không thể tải model cho {ticker}: {e}")
    return None, None

def get_period_change(df, days):
    """Tính toán phần trăm thay đổi giá trong một khoảng thời gian nhất định."""
    try:
        current_p = df['Close'].iloc[-1]
        if len(df) > days:
            past_p = df['Close'].iloc[-(days + 1)]
            return ((current_p - past_p) / past_p) * 100
        return 0
    except: return 0
