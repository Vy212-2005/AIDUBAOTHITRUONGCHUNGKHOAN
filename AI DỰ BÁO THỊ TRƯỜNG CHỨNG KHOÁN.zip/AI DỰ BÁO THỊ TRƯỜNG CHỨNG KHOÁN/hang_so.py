import streamlit as st

# --- CẤU HÌNH ---
DUONG_DAN_PYTHON = r"C:\Users\LOQ\anaconda3\envs\stock_ai\python.exe"

# --- GIAO DIỆN NÂNG CAO (CSS) ---
CSS_GIAO_DIEN = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif;
    }

    .main {
        background-color: #06080c;
    }
    
    /* Phong cách tiêu đề chính */
    .main-title {
        font-weight: 800;
        letter-spacing: -1px;
        background: linear-gradient(90deg, #4facfe 0%, #0099ff 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-size: 2.5rem;
        margin-bottom: 0.5rem;
    }
    
    /* Phong cách thẻ (Card) */
    .metric-card {
        background: rgba(16, 18, 22, 0.8);
        border: 1px solid rgba(255, 255, 255, 0.05);
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.5);
        transition: all 0.3s ease;
    }
    .metric-card:hover {
        border: 1px solid rgba(79, 172, 254, 0.3);
        background: rgba(16, 18, 22, 0.9);
    }
    
    .metric-label {
        color: #94a3b8;
        font-size: 0.8rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        margin-bottom: 4px;
    }
    
    .metric-value {
        color: #f8fafc;
        font-size: 1.8rem;
        font-weight: 700;
    }
    
    .metric-delta-up { color: #10b981; font-size: 0.85rem; font-weight: 600; }
    .metric-delta-down { color: #ef4444; font-size: 0.85rem; font-weight: 600; }
    
    /* Phong cách khung nhập liệu */
    .stTextInput>div>div>input {
        background-color: rgba(255, 255, 255, 0.05) !important;
        color: white !important;
        border-radius: 10px !important;
        border: 1px solid rgba(255, 255, 255, 0.1) !important;
    }
    
    /* Phong cách nút bấm */
    .stButton>button {
        border-radius: 12px !important;
        background: linear-gradient(135deg, #00f2fe 0%, #4facfe 100%) !important;
        color: #0e1117 !important;
        font-weight: 700 !important;
        border: none !important;
        padding: 10px 20px !important;
        transition: all 0.3s ease !important;
    }
    .stButton>button:hover {
        box-shadow: 0 0 20px rgba(79, 172, 254, 0.6) !important;
        transform: scale(1.02) !important;
    }
</style>
"""
