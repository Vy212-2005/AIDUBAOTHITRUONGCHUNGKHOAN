import streamlit as st
import yfinance as yf
import time

def display_news(ticker, news_mode):
    """Lấy và hiển thị tin tức thị trường hoặc tin tức mã cụ thể."""
    news_list = []
    if news_mode == "🌍 Tài chính Thế giới":
        indices = ["^GSPC", "^DJI", "^IXIC"]
        for idx in indices:
            try: news_list.extend(yf.Ticker(idx).news)
            except: continue
        news_list = sorted({item['uuid']: item for item in news_list if 'uuid' in item}.values(), key=lambda x: x.get('provider_publish_time') or 0, reverse=True)
    else:
        try: news_list = yf.Ticker(ticker).news
        except: news_list = []

    if not news_list:
        st.info("Hiện tại chưa có tin tức mới cập nhật.")
    else:
        for item in news_list[:12]:
            with st.container():
                col_n1, col_n2 = st.columns([1, 4])
                content = item.get('content', {})
                title = content.get('title', item.get('title', 'Tiêu đề tin tức'))
                link = content.get('canonicalUrl', {}).get('url', item.get('link', '#'))
                publisher = content.get('provider', {}).get('displayName', item.get('publisher', 'Nguồn tin'))
                thumb = content.get('thumbnail', item.get('thumbnail', {}))
                img_url = (thumb.get("resolutions", [{}])[0].get("url") if thumb.get("resolutions") else thumb.get("originalUrl"))
                
                with col_n1:
                    if img_url: st.image(img_url, use_container_width=True)
                    else: st.markdown("<div style='background: #1e293b; height: 70px; display: flex; align-items: center; justify-content: center; border-radius: 8px;'>📰</div>", unsafe_allow_html=True)
                with col_n2:
                    st.markdown(f"**[{title}]({link})**")
                    pub_time = content.get('pubDate', "").replace('T', ' ').replace('Z', '')[:16] or time.strftime('%Y-%m-%d %H:%M', time.localtime(item.get('provider_publish_time', 0)))
                    st.caption(f"🕒 {pub_time} | {publisher}")
                st.divider()
