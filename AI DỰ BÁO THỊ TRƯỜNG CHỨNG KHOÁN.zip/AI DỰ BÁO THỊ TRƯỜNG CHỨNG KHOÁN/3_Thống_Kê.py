import streamlit as st
from ta.trend import SMAIndicator, EMAIndicator
from ta.momentum import RSIIndicator

def draw_perf_card(col, label, value):
    """Vẽ thẻ hiển thị hiệu suất biến động."""
    color = "#10b981" if value >= 0 else "#ef4444"
    icon = "▲" if value >= 0 else "▼"
    col.markdown(f"""
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05); border-radius: 12px; padding: 15px; text-align: center; backdrop-filter: blur(5px);">
            <div style="color: #94a3b8; font-size: 0.7rem; font-weight: 600; margin-bottom: 5px; text-transform: uppercase; letter-spacing: 1px;">{label}</div>
            <div style="color: {color}; font-size: 1.4rem; font-weight: 800;">{icon} {value:+.2f}%</div>
        </div>
    """, unsafe_allow_html=True)

def draw_metric_card(col, label, value, delta=None, delta_text=""):
    """Vẽ thẻ hiển thị các chỉ số chi tiết."""
    delta_class = "metric-delta-up" if (delta and delta >= 0) else "metric-delta-down"
    delta_val = f"{delta:+.2f}%" if delta is not None else delta_text
    col.markdown(f"""
        <div class="metric-card">
            <div class="metric-label">{label}</div>
            <div class="metric-value">{value}</div>
            <div class="{delta_class}">{delta_val}</div>
        </div>
    """, unsafe_allow_html=True)

def get_technical_indicators(df):
    """Tính toán các chỉ số kỹ thuật cơ bản."""
    df = df.copy()
    df['SMA20'] = SMAIndicator(close=df['Close'], window=20).sma_indicator()
    df['SMA50'] = SMAIndicator(close=df['Close'], window=50).sma_indicator()
    df['EMA20'] = EMAIndicator(close=df['Close'], window=20).ema_indicator()
    df['RSI'] = RSIIndicator(close=df['Close'], window=14).rsi()
    return df
