import streamlit as st
import google.generativeai as genai
import time
import os
import numpy as np
import joblib
from pathlib import Path
from tensorflow.keras.models import load_model

def cau_hinh_gemini(key):
    """Thiết lập AI Gemini cho việc dự báo."""
    if not key: return None
    try:
        genai.configure(api_key=key)
        models = [m.name for m in genai.list_models() if 'generateContent' in m.supported_generation_methods]
        name = next((m for m in ['models/gemini-1.5-flash', 'models/gemini-pro'] if m in models), models[0])
        model = genai.GenerativeModel(name)
        st.sidebar.success(f"Dự báo sẵn sàng: {name}")
        return model
    except Exception as e:
        st.sidebar.error(f"Lỗi AI: {e}")
    return None

def goi_phan_tich_ai(model, context, anh=None):
    """Gửi dữ liệu thị trường cho AI phân tích."""
    try:
        dau_vao = [context]
        if anh: dau_vao.append(anh)
        res = model.generate_content(dau_vao)
        return res.text, None
    except Exception as e:
        return None, str(e)

def du_bao_gia_keras(df, ticker):
    """Sử dụng mô hình LSTM đã train (nếu có) để dự báo giá ngày kế tiếp."""
    ticker_low = ticker.lower()
    
    # Sử dụng đường dẫn tuyệt đối dựa trên vị trí file này
    base_dir = Path(__file__).parent
    model_path = base_dir / f'model_{ticker_low}.keras'
    scaler_path = base_dir / f'scaler_{ticker_low}.pkl'
    
    if not model_path.exists() or not scaler_path.exists():
        # st.sidebar.info(f"DEBUG: Missing {model_path.name}") # Optional debug
        return None, "Chưa có Model cho mã này"
    
    try:
        # Load model và scaler (chuyển sang string cho Keras/Joblib nếu cần)
        model = load_model(str(model_path))
        scaler = joblib.load(str(scaler_path))
        
        # Đặc trưng giống như trong train_model.py
        feature_cols = ['Open', 'High', 'Low', 'Close', 'SMA20', 'SMA50', 'EMA20', 'RSI', 'Volume']
        
        # Lấy 60 ngày gần nhất
        if len(df) < 60:
            return None, "Cần tối thiểu 60 ngày dữ liệu"
            
        last_60_days = df[feature_cols].tail(60).values
        
        # Scale
        scaled_data = scaler.transform(last_60_days)
        
        # Reshape cho LSTM: (1, 60, n_features)
        X_input = np.array([scaled_data])
        
        # Predict
        prediction_scaled = model.predict(X_input, verbose=0)
        
        # Inverse Scale (để lấy giá thực tế)
        # Vì scaler fit trên toàn bộ features, ta cần tạo 1 array dummy để inverse
        dummy = np.zeros((1, len(feature_cols)))
        target_idx = feature_cols.index('Close')
        dummy[0, target_idx] = prediction_scaled[0, 0]
        
        prediction_final = scaler.inverse_transform(dummy)[0, target_idx]
        
        return prediction_final, None
    except Exception as e:
        return None, f"Lỗi dự báo: {str(e)}"
