import streamlit as st
import google.generativeai as genai
import time

def cau_hinh_gemini(key):
    """Thiết lập AI Gemini cho việc dự báo."""
    if not key: return None
    try:
        genai.configure(api_key=key)
        models = [m.name for m in genai.list_models() if 'generateContent' in m.supported_generation_methods]
        name = next((m for m in ['models/gemini-1.5-flash', 'models/gemini-pro'] if m in models), models[0])
        model = genai.GenerativeModel(name)
        st.sidebar.success(f"Dự báo sẵn sàng: {name}")
        return model
    except Exception as e:
        st.sidebar.error(f"Lỗi AI: {e}")
    return None

def goi_phan_tich_ai(model, context, anh=None):
    """Gửi dữ liệu thị trường cho AI phân tích."""
    try:
        dau_vao = [context]
        if anh: dau_vao.append(anh)
        res = model.generate_content(dau_vao)
        return res.text, None
    except Exception as e:
        return None, str(e)
